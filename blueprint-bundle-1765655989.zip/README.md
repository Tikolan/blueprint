# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 13.12.2025 19:59

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `blueprintcreator-1765655985.zip`
- `custom-post-type-ui-1765655985.zip`
- `events-manager-1765655985.zip`
- `gallery-block-lightbox-1765655986.zip`
- `meinfesterpost-1765655986.zip`
- `export-1765655983.xml`
- `export-1765655983.xml`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** MTB-Niederneukirchen
**Schritte:** 9
