# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 04.01.2026 12:50

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `advpresent-1767531027.zip`
- `export-content-1767531025.xml`
- `media-1767531025.zip`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** adv Präsentation
**Schritte:** 5
