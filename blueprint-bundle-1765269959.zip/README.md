# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 09.12.2025 08:45

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `blueprintcreator-1765269936.zip`
- `export-1765269931.xml`
- `export-1765269931.xml`

## 🚀 Verwendung

### Direct Playground Link
Die Dateien wurden mit der Base-URL konfiguriert:
`https://github.com/Tikolan/blueprint/`

Nach dem Upload können Sie direkt auf playground.wordpress.net verwenden.

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Die Pfade in `blueprint.json` sind bereits konfiguriert für: https://github.com/Tikolan/blueprint/
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** My WordPress Website
**Schritte:** 6
