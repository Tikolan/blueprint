# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 03.01.2026 06:07

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `advpresent-1767420458.zip`
- `export-content-1767420455.xml`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** Präsentation
**Schritte:** 3
