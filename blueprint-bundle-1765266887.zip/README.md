# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 09.12.2025 07:54

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie `./` mit der vollständigen URL
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** Dev Vorne
**Schritte:** 7
