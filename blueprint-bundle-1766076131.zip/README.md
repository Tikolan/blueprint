# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 18.12.2025 16:42

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `blueprintcreatordebugs-1766075989.zip`
- `blueprintcreator-1766075989.zip`
- `blocknavigation22b-1766075989.zip`
- `export-content-1766075989.xml`
- `export-fse-1766075989.xml`
- `media-1766075989.zip`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** TEST
**Schritte:** 11
