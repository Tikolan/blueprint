# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 10.12.2025 16:36

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `taxfilter-1765384583.zip`
- `blueprintcreator-1765384583.zip`
- `custompostexport-1765384583.zip`
- `einfachezeit-1765384583.zip`
- `blocknavigation-1765384583.zip`
- `etiketten-1765384583.zip`
- `extensions-leaflet-map-1765384583.zip`
- `fast-user-switching-1765384584.zip`
- `githubuploader-1765384584.zip`
- `gpx2-1765384584.zip`
- `html-album-importer-1765384584.zip`
- `html-album-importer-1765384584.zip`
- `html-album-importer-1765384584.zip`
- `gallery-block-lightbox-1765384584.zip`
- `mediaupload-1765384584.zip`
- `meinfesterpost-1765384584.zip`
- `member-email-login-1765384584.zip`
- `rss-importer-1765384584.zip`
- `signup-EVAL-23-1765384584.zip`
- `wp-add-mime-types-1765384584.zip`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** My WordPress Website
**Schritte:** 26
