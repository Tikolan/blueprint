# WordPress Playground Blueprint Bundle

Erstellt mit Blueprint Creator am 26.12.2025 10:19

## 📦 Inhalt

- `blueprint.json` - Blueprint-Konfiguration
- `blueprintcreator-1766744397.zip`
- `meinfesterpost-1766744397.zip`
- `export-content-1766744389.xml`
- `export-fse-1766744389.xml`
- `media-1766744389.zip`

## 🚀 Verwendung

### Option 1: Hochladen & URL verwenden
1. Extrahieren Sie diese ZIP-Datei
2. Laden Sie alle Dateien auf einen Webserver oder GitHub hoch
3. Öffnen Sie `blueprint.json` und ersetzen Sie die Pfade mit vollständigen URLs
4. Verwenden Sie den Blueprint auf playground.wordpress.net

### Option 2: Lokal mit Playground CLI
```bash
npx @wp-now/wp-now start --blueprint=blueprint.json
```

## 📋 Blueprint Details

**Website:** MTB-Niederneukirchen
**Schritte:** 15
